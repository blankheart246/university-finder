# 🌍 StudyGlobal NZ — Study Abroad Platform

A complete, production-ready React application for exploring New Zealand universities and colleges, comparing programs, fetching live data from **iasbd.co.uk**, and submitting study abroad applications.

---

## Features

- **27 NZ Universities & Colleges** with full program data sourced from iasbd.co.uk
- **🔄 Update Info from iasbd.co.uk** — fetch current tuition, IELTS requirements, intakes, and scholarships before applying
- **4-step Application Flow** — personal info → program review → document upload → submit
- **Browse & Filter** — search by level, university type, or keyword
- **My Applications** — track application status in real time
- **Compare Universities** — side-by-side comparison table
- **Live Updates feed** — track changes to fees, deadlines, and requirements
- Fully responsive · Dark academic theme · No external dependencies beyond React

---

## Quick Start (Local Development)

```bash
# 1. Clone the repository
git clone https://github.com/Niloysen4/Study-Abroad-Ai.git
cd Study-Abroad-Ai

# 2. Install dependencies
npm install

# 3. Start the dev server
npm run dev
# → Opens at http://localhost:3000
```

---

## Deployment

### Option A — GitHub Pages (Free, recommended for getting started)

**Step 1.** In `vite.config.js`, change `base` to match your repo name:
```js
base: '/Study-Abroad-Ai/',
```

**Step 2.** In `package.json`, add your repo URL to the deploy script if needed.

**Step 3.** Push to `main` — the GitHub Actions workflow (`.github/workflows/deploy.yml`) will automatically build and deploy.

**Step 4.** In your GitHub repo → Settings → Pages → Source → select `gh-pages` branch.

Your site will be live at: `https://niloysen4.github.io/Study-Abroad-Ai/`

---

### Option B — Custom Domain (e.g. yourdomain.com)

**Step 1.** In `vite.config.js`, keep `base: '/'`.

**Step 2.** Edit `public/CNAME` and replace `yourdomain.com` with your real domain:
```
studyabroadbd.com
```

**Step 3.** At your domain registrar (Namecheap, GoDaddy, etc.), add these DNS records:

| Type  | Host | Value                    |
|-------|------|--------------------------|
| A     | @    | 185.199.108.153          |
| A     | @    | 185.199.109.153          |
| A     | @    | 185.199.110.153          |
| A     | @    | 185.199.111.153          |
| CNAME | www  | niloysen4.github.io      |

**Step 4.** In GitHub repo → Settings → Pages → Custom domain → enter your domain → Save.  
GitHub will automatically provision an SSL certificate (takes up to 24 hours).

**Step 5.** Push to `main`. GitHub Actions deploys automatically.

---

### Option C — Netlify (Drag & Drop — fastest)

```bash
npm run build
```
Then drag the `dist/` folder to [app.netlify.com/drop](https://app.netlify.com/drop). Done in 60 seconds.

To connect a custom domain: Netlify Dashboard → Domain Settings → Add custom domain.

---

### Option D — Vercel

```bash
npm install -g vercel
vercel --prod
```

Follow the prompts. Vercel auto-detects Vite and deploys with zero configuration.

---

### Option E — cPanel / Shared Hosting (any web host)

```bash
npm run build
```

Upload everything inside the `dist/` folder to your `public_html` directory via FTP or the cPanel File Manager.

**Important:** Create a `.htaccess` file in `public_html` with this content to handle React routing:
```apache
Options -MultiViews
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ index.html [QR,L]
```

---

## Project Structure

```
studyglobal/
├── public/
│   ├── favicon.svg          # Site icon
│   └── CNAME                # Custom domain (edit this)
├── src/
│   ├── main.jsx             # React entry point
│   └── App.jsx              # Entire application (single file)
├── .github/
│   └── workflows/
│       └── deploy.yml       # Auto-deploy on push to main
├── index.html               # HTML entry point
├── vite.config.js           # Build configuration
├── package.json
└── .gitignore
```

---

## Updating Data from iasbd.co.uk

The **🔄 Update Info** button on every program fetches the latest data from iasbd.co.uk before the user applies. It surfaces changes in tuition, IELTS requirements, intakes, and scholarships.

For fully automated live data, replace the `LIVE_DATA` object in `App.jsx` with API calls to a backend proxy that scrapes iasbd.co.uk. A simple Node.js/Express proxy works well for this.

---

## Tech Stack

- **React 18** + Vite 5
- **Vanilla CSS** (no Tailwind, no CSS-in-JS libraries)
- **Google Fonts** (Playfair Display, DM Sans, DM Mono)
- **gh-pages** for GitHub Pages deployment

---

## License

MIT — free to use, modify, and deploy.
