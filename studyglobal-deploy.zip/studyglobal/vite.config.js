import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// ─── DEPLOYMENT CONFIGURATION ─────────────────────────────────────────────────
// For GitHub Pages:       set base to '/<your-repo-name>/'  e.g. '/Study-Abroad-Ai/'
// For a custom domain:    set base to '/'  (this is the correct setting)
// ─────────────────────────────────────────────────────────────────────────────

export default defineConfig({
  plugins: [react()],
  base: '/',          // ← change to '/Study-Abroad-Ai/' if using GitHub Pages without a custom domain
  build: {
    outDir: 'dist',
    sourcemap: false,
    minify: 'terser',
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom'],
        },
      },
    },
  },
  server: {
    port: 3000,
    open: true,
  },
})
